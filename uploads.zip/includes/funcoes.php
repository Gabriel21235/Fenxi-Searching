<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/../config/conexao.php';

function e(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_input(): string {
    return '<input type="hidden" name="csrf_token" value="'.e(csrf_token()).'">';
}

function csrf_valido(?string $token): bool {
    return is_string($token) && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function exigir_csrf(): void {
    if (!csrf_valido($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        exit('Requisição inválida.');
    }
}

function usuario_id(): ?int {
    return isset($_SESSION['usuario_id']) ? (int)$_SESSION['usuario_id'] : null;
}

function usuario_logado(): bool {
    return usuario_id() !== null;
}

function exigir_login(): void {
    if (!usuario_logado()) {
        header('Location: login.php');
        exit;
    }
}

function admin_logado(): bool {
    return isset($_SESSION['admin_id']);
}

function exigir_admin(): void {
    if (!admin_logado()) {
        header('Location: login.php');
        exit;
    }
}

function usuario_atual(PDO $pdo): ?array {
    if (!usuario_logado()) return null;
    $st = $pdo->prepare(
        'SELECT u.*, p.nome_plano, p.preco, p.limite_edicoes_dia, p.cooldown_horas,
                p.modelo_ia, p.permite_zip, p.marca_dagua, p.exibe_ads,
                p.limite_upload_mb, p.limite_favoritos
         FROM usuarios u
         JOIN planos p ON p.id_plano = u.id_plano
         WHERE u.id_usuario = :id LIMIT 1'
    );
    $st->execute([':id'=>usuario_id()]);
    return $st->fetch() ?: null;
}

function plano_atual(PDO $pdo, int $idPlano): array {
    $st=$pdo->prepare('SELECT * FROM planos WHERE id_plano=:id LIMIT 1');
    $st->execute([':id'=>$idPlano]);
    return $st->fetch() ?: [];
}

function edicoes_hoje(PDO $pdo, int $idUsuario): int {
    $st=$pdo->prepare('SELECT COUNT(*) FROM edicoes WHERE id_usuario=:id AND data_edicao >= CURDATE()');
    $st->execute([':id'=>$idUsuario]);
    return (int)$st->fetchColumn();
}

function segundos_cooldown(PDO $pdo, int $idUsuario, int $horas): int {
    if ($horas <= 0) return 0;
    $st=$pdo->prepare(
        'SELECT TIMESTAMPDIFF(SECOND, NOW(), DATE_ADD(data_download, INTERVAL :h HOUR))
         FROM downloads WHERE id_usuario=:id ORDER BY data_download DESC LIMIT 1'
    );
    $st->execute([':h'=>$horas, ':id'=>$idUsuario]);
    $v=$st->fetchColumn();
    return $v === false || $v === null ? 0 : max(0,(int)$v);
}

function formatar_tempo(int $segundos): string {
    $h=intdiv($segundos,3600); $m=intdiv($segundos%3600,60);
    return $h.'h '.str_pad((string)$m,2,'0',STR_PAD_LEFT).'min';
}

function formatar_data(?string $data): string {
    if (!$data) return '';
    return date('d/m/Y H:i', strtotime($data));
}

function tipo_generico(string $mime): string {
    if (str_starts_with($mime,'image/')) return 'imagem';
    if (str_starts_with($mime,'video/')) return 'video';
    if (str_starts_with($mime,'audio/')) return 'audio';
    return 'arquivo';
}

function render_header(string $titulo, ?array $user=null, string $base=''): void {
    $nome=$user['usu_nome'] ?? 'Visitante';
    $logado=$user !== null;
    ?>
    <!doctype html>
    <html lang="pt-BR">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title><?=e($titulo)?> · Fênix Searching</title>
      <link rel="stylesheet" href="<?=e($base)?>assets/css/style.css">
    </head>
    <body>
    <header class="topbar">
      <div class="container topbar-inner">
        <a class="brand" href="<?=e($base)?><?= $logado ? 'dashboard.php' : 'index.php' ?>"><span class="phoenix">✦</span> FÊNIX <span>SEARCHING</span></a>
        <nav class="nav-links">
          <a href="<?=e($base)?>index.php">Início</a>
          <a href="<?=e($base)?>pesquisa.php">Explorar</a>
          <?php if ($logado): ?>
            <a href="<?=e($base)?>upload.php">Upload</a>
            <a href="<?=e($base)?>ia.php">IA</a>
            <a href="<?=e($base)?>dashboard.php">Dashboard</a>
          <?php endif; ?>
        </nav>
        <div class="top-actions">
          <?php if ($logado): ?>
            <span class="user-mini"><?=e($nome)?></span>
            <a class="btn btn-small btn-outline" href="<?=e($base)?>logout.php">Sair</a>
          <?php else: ?>
            <a class="btn btn-small btn-outline" href="login.php">Entrar</a>
            <a class="btn btn-small btn-primary" href="cadastro.php">Cadastrar</a>
          <?php endif; ?>
        </div>
      </div>
    </header>
    <main>
    <?php
}

function render_footer(string $base=''): void {
    ?>
    </main>
    <footer class="footer"><div class="container">Fênix Searching · TCC 2026</div></footer>
    <script src="<?=e($base)?>assets/js/app.js"></script>
    </body></html>
    <?php
}

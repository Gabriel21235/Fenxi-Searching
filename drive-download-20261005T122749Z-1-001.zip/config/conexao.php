<?php
declare(strict_types=1);

/*
 * Fênix Searching — conexão central com MySQL.
 * Banco: Fenix_Searching
 * Ambiente alvo: XAMPP / localhost
 */

$host = getenv('FENIX_DB_HOST') ?: 'localhost:3307';
$port = getenv('FENIX_DB_PORT') ?: '3306';
$db   = getenv('FENIX_DB_NAME') ?: 'Fenix_Searching';
$user = getenv('FENIX_DB_USER') ?: 'root';
$pass = getenv('FENIX_DB_PASS') ?: 'admin';

$dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log('[Fenix Searching] DB: '.$e->getMessage());
    http_response_code(500);
    exit('Não foi possível conectar ao banco de dados. Verifique o MySQL do XAMPP e a configuração da conexão.');
}
